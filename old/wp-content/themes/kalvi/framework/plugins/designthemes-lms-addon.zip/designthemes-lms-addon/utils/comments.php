<?php
	if ( post_password_required() ) {
		return;
	}
?>

<div id="comments" class="comments-area">
    <?php if ( have_comments() ) : ?>

	    <h3><?php comments_number(esc_html__('No Comments','kalvi'), esc_html__('Comment ( 1 )','kalvi'), esc_html__('Comments ( % )','kalvi') );?></h3>

		<?php the_comments_navigation(); ?>

        <ul class="commentlist">
     		<?php wp_list_comments( array( 'callback' => 'kalvi_comment_style' ) ); ?>
        </ul>

        <?php the_comments_navigation(); ?>

    <?php endif; ?>

	<?php if ( ! comments_open() && get_comments_number() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
        <p class="nocomments"><?php esc_html_e( 'Comments are closed.','kalvi'); ?></p>
    <?php endif;?>    
	
	<?php
	

	$fields =  array(
        "author" => '<div class="dtlms-column dtlms-one-half first"><p>
		<label for="title">'.esc_html__( 'Name', 'dtlms' ).'</label>
		<input id="author" name="author" type="text" required />
	</p></div>',
        "email"  => '<div class="dtlms-column dtlms-one-half"><p>
		<label for="title">'.esc_html__( 'Email', 'dtlms' ).'</label>
		<input id="email" name="email" type="text" required />
	</p></div>',
    );	

	if( cs_get_option('privacy-commentform') == "true" ) {

        $content = do_shortcode( cs_get_option('privacy-commentform-msg') );

        $fields['comment-form-dt-privatepolicy'] = '<p class="comment-form-dt-privatepolicy">
            <input id="comment-form-dt-privatepolicy" name="comment-form-dt-privatepolicy" type="checkbox" value="yes">
            <label for="comment-form-dt-privatepolicy">'.$content.'</label> </p>';
    }
	
	$comments_args = array(
		'title_reply' 			=> 	esc_html__( 'Leave a Comment','kalvi' ),
		'fields'				=> 	$fields,
		'comment_notes_before'	=>	'',
		'label_submit'			=>	esc_html__('Comment','kalvi'));

	comment_form($comments_args);?>

</div><!-- .comments-area -->